<?php
	$flag = "MeePwnCTF{__OMG!!!__Y0u_Are_Milli0naire_N0ww!!___}";
?>
