#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys \
    , argparse \
    , tempfile \
    , json

from os.path import basename

from wave_reader import WaveReader
from utils import Converter

####
# Parses CLI arguments
####
parser = argparse.ArgumentParser ()

parser.add_argument ("wav_file"
                    , help = "File or list of files in .wav format to be processed"
                    , nargs = "+"
)

parser.add_argument ("-v", "--verbose"
                    , help = "Shows every step taken to get the data"
                    , action = "store_true"
)

parser.add_argument ("-o", "--output"
                    , type = argparse.FileType ("w")
                    , help = "Stores the final data on the specified file, on"\
                            + " JSON format"
)

parser.add_argument ("-f", "--fast"
                    , help = "Tries to filter and square the wave at once. This method"\
                            + " is faster, but may give worse results"
                    , action = "store_true"
)

args = parser.parse_args ()

files = args.wav_file
verbose = args.verbose
fast = args.fast
out_file = args.output
####
# Arguments parsed
#### -----------------------------------------------------------------

json_data = {}

for f in files:

    if verbose:
        print "\n ---------------- "
        print " => Processing file " + f + ": "

    # Filters and squares the wave
    if not fast:
        file_filtered = tempfile.NamedTemporaryFile ("w", prefix = "wave_filtered_")
    file_squared = tempfile.NamedTemporaryFile ("w", prefix = "wave_squared_")

    if fast:
        # Fast process
        with WaveReader (f) as r:
            # Writes the filtered and squared wave on 'file_squared'
            r.filter_and_square_wave (file_squared.name)
        if verbose:
            print " -> Wave filtered and squared"
    else:
        # Conventional process
        with WaveReader (f) as r:
            r.filter_wave (file_filtered.name)

        if verbose:
            print " -> Wave filtered"

        with WaveReader (file_filtered.name) as r:
            r.square_wave (file_squared.name)

        if verbose:
            print " -> Wave squared"


    # Retrieves the data on file_squared
    with WaveReader (file_squared.name) as r:
        data = r.get_data ()


    if verbose:
        print "\n --> Data retrieved: "
        for packet in data:
            print "\t ==> " + packet

    else:
        print data

    # Stores the data on the output file, if the option was set
    if out_file:
        json_data [basename (f)] = data


    # Closes all the temporary files
    if not fast:
        file_filtered.close ()
    file_squared.close ()

if verbose:
    print "All files processed"

if out_file:
    out_file.write (json.dumps (json_data))
