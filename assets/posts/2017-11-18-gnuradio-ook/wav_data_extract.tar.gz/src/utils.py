#!/usr/bin/env python
# -*- coding: utf-8 -*-


import re
import struct

class Converter:
    """
    Class with the needed methods to convert between data types
    """

    regex_no_hex = "[^a-fA-F0-9]"

    strip_no_hex = staticmethod (
            lambda s: re.sub (Converter.regex_no_hex
                            , ""
                            , re.sub ("0x", "", s)
            )
    )



    @staticmethod
    def get_hex2int_converter (samp_width):
        """
        Returns a function to convert correctly the hexadecimal values on the wave file
        (LITTLE ENDIAN) into their decimal representation

        Args:
            samp_width -> Width of the samples taken

        Returns:
            A function that can be used to convert the hex values (as strings) into int
        """
        if samp_width == 1:
            # 8-bit, unsigned
#            convert = lambda x: Converter.hexstr_uint8 (x)
            convert = lambda x: struct.unpack ("<b", x)[0]

        elif samp_width == 2:
            # 16-bit, signed
#            convert = lambda x: Converter.hexstr_int16 (x)
            convert = lambda x: struct.unpack ("<h", x)[0]

        else:
            # 32-bit, signed
#            convert = lambda x: Converter.hexstr_int32 (x)
            convert = lambda x: struct.unpack ("<l", x)[0]

        return convert


    @staticmethod
    def get_int2hex_converter (samp_width):
        """
        Returns a function to convert correctly the integer values on the wave file into
        their hexadecimal representation (LITTLE-ENDIAN)

        Args:
            samp_width -> Width of the samples taken

        Returns:
            A function that can be used to convert the int values into hex (as strings),
            in little-endian
        """
        if samp_width == 1:
#            convert = lambda x: Converter.uint8_hexstr (x)
            convert = lambda x: struct.pack ("<b", x)

        elif samp_width == 2:
#            convert = lambda x: Converter.int16_hexstr (x)
            convert = lambda x: struct.pack ("<h", x)

        else:
#            convert = lambda x: Converter.int32_hexstr (x)
            convert = lambda x: struct.pack ("<l", x)

        return convert


    # ----------- vvvv ----- hex2int and int2hex methods ---- vvvvv --------------

    ####
    # 32 Bit
    ####

    @staticmethod
    def hexstr_int32 (str_hex):
        """
        Converts the string from an hex string to a signed 32-bit integer

        Args:
            str_hex -> String with the hexadecimal value to be converted

        Returns:
            The value, converted to a signed 32-bit integer

        Throws:
            ValueError if the number exceeds the range of the end type or the string is
            not a valid hex value
        """
        original = str_hex
        str_hex = Converter.strip_no_hex (original)

        if not str_hex:
            raise ValueError ("'" + original + "' is not a valid hexadecimal value")

        x = int (str_hex, 16)

        if x > (2 ** 32):
            raise ValueError ("Value '" + hex (x) + "' exceeds the range of "
                            + "a signed 32-bit integer")

        if x > 0x7fffffff:
            x -= 0x100000000

        return x

    @staticmethod
    def int32_hexstr (int_val):
        """
        Converts the signed 32-bit integer into an hex string

        Args:
            int_val -> 32-bit integer (signed) to be converted

        Returns:
            The value, converted to a string with the hexadecimal value, with the
            additional characters ('0x', 'L'...) stripped and zero-padded

        Throws:
            ValueError if the number exceeds the range of the end type
        """
        if int_val >= (2 ** 31) or int_val < -(2 ** 31):
            raise ValueError ("Value '" + str (int_val) + "' exceeds the range of "
                            + "a signed 32-bit integer")

        return Converter.strip_no_hex (hex (int_val & ((2 ** 32) - 1))).zfill (8)



    ####
    # 16 Bit
    ####


    @staticmethod
    def hexstr_int16 (str_hex):
        """
        Converts the string from an hex string to a signed 16-bit integer

        Args:
            str_hex -> String with the hexadecimal value to be converted

        Returns:
            The value, converted to a signed 16-bit integer

        Throws:
            ValueError if the number exceeds the range of the end type or the string is
            not a valid hex value
        """
        original = str_hex
        str_hex = Converter.strip_no_hex (original)

        if not str_hex:
            raise ValueError ("'" + original + "' is not a valid hexadecimal value")

        x = int (str_hex, 16)

        if x > (2 ** 16):
            raise ValueError ("Value '" + hex (x) + "' exceeds the range of "
                            + "a signed 16-bit integer")

        if x > 0x7fff:
            x -= 0x10000

        return x

    @staticmethod
    def int16_hexstr (int_val):
        """
        Converts the signed 16-bit integer into an hex string

        Args:
            int_val -> 16-bit integer (signed) to be converted

        Returns:
            The value, converted to a string with the hexadecimal value, with the
            additional characters ('0x', 'L'...) stripped and zero-padded

        Throws:
            ValueError if the number exceeds the range of the end type
        """
        if int_val >= (2 ** 15) or int_val < -(2 ** 15):
            raise ValueError ("Value '" + str (int_val) + "' exceeds the range of "
                            + "a signed 16-bit integer")

        return Converter.strip_no_hex (hex (int_val & ((2 ** 16) - 1))).zfill (4)




    ####
    # 8 Bit
    ####

    @staticmethod
    def hexstr_uint8 (str_hex):
        """
        Converts the string from an hex string to an unsigned 8-bit integer

        Args:
            str_hex -> String with the hexadecimal value to be converted

        Returns:
            The value, converted to an unsigned 8-bit integer

        Throws:
            ValueError if the number exceeds the range of the end type or the string is
            not a valid hex value
        """
        original = str_hex
        str_hex = Converter.strip_no_hex (original)

        if not str_hex:
            raise ValueError ("'" + original + "' is not a valid hexadecimal value")

        x = int (str_hex, 16)

        if x > (2 ** 8):
            raise ValueError ("Value '" + hex (x) + "' exceeds the range of " \
                            + "an unsigned 8-bit integer")
        return x

    @staticmethod
    def uint8_hexstr (int_val):
        """
        Converts the unsigned 8-bit integer into an hex string

        Args:
            int_val -> 8-bit integer (signed) to be converted

        Returns:
            The value, converted to a string with the hexadecimal value, with the
            additional characters ('0x', 'L'...) stripped and zero-padded

        Throws:
            ValueError if the number exceeds the range of the end type
        """
        original = int_val

        if int_val >= (2 ** 8) or int_val < 0:
            raise ValueError ("Value '" + str (original) + "' exceeds the range of "
                            + "a signed 8-bit integer")

        return "%02x" % int_val

