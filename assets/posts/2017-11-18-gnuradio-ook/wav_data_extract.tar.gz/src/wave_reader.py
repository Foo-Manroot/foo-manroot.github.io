#!/usr/bin/env python
# -*- coding: utf-8 -*-


import wave
import binascii
import struct
import re

from utils import Converter


class WaveReader ():
    """
    Class with all the needed methods to process a WAV file
    """

    def __init__ (self, in_file, buff_size = 1024):
        """
        Constructor

        Args:
            in_file -> Name of the .wav file with the data
            buff_size (optional) -> Size of the buffer used to read data
        """
        self.in_file = in_file
        self.reader = None
        self.buff_size = buff_size

    ###
    # Helper methods (constructors/destructors/whatever)
    ###


    def __enter__ (self):
        """
        Method to be called when the 'with' statement starts.
        Opens the reader to stream data
        """
        self.reader = wave.open (self.in_file, "r")

        samp_width = self.reader.getsampwidth ()
        self.int2hex = Converter.get_int2hex_converter (samp_width)
        self.hex2int = Converter.get_hex2int_converter (samp_width)

        return self

    def __exit__ (self, exc_type, exc_val, exc_tb):
        """
        Method to be called when the 'with' statement ends.
        Closes the open files
        """
        self.reader.close ()

    def __del__ (self):
        """
        Method to be called when the object is destructed.
        Closes the open files
        """
        self.reader.close ()



    def get_reader (self):
        """
        Returns the object used to read the wave file. If it's not instatiated, creates
        it before returning it
        """
        if self.reader is None:
            self.reader = wave.open (self.in_file, "r")

            samp_width = self.reader.getsampwidth ()
            self.int2hex = Converter.get_int2hex_converter (samp_width)
            self.hex2int = Converter.get_hex2int_converter (samp_width)

        return self.reader


    ###
    # Methods to read data and manipulate the state of 'self.reader'
    ###


    def get_pos (self):
        """
        Gets the position of the pointer
        """
        return self.reader.tell ()


    def set_pos (self, pos = 0):
        """
        Sets the pointer on the specified frame of the file

        Args:
            pos (optional) -> Frame where the pointer will be set
        """
        if pos <= 0:
            self.reader.rewind ()
        else:
            self.reader.setpos (pos)



    def get_batch (self, n = None, mono = True):
        """
        Reads a certain number of frames and returns an array with their hexadecimal
        values

        Args:
            n (optional) -> Maximum number of frames to be returned
            mono (optional) -> If 'True', returns only the first channel of the frame.
                    If it's 'False', returns all channels together on the same position
                    of the array

        Returns:
            An array with, at most, 'n' positions
        """
        ret_val = []
        if not n: n = self.buff_size
        channels = self.reader.getnchannels ()
        width = self.reader.getsampwidth () * channels

        batch = self.reader.readframes (n)
        data = map (''.join, zip (* [iter (batch)] * width) )

        return [
                frame [:len (frame) / channels] if mono
                else frame
                for frame in data
        ]


    def filter_wave (self, out_file, n_elems = 50):
        """
        Applies a filter to the wave and stores it on the specified output file

        Args:
            out_file -> Name of the file to store the filtered wave
            n_elems (optional) -> Number of elements to take as a batch
        """
        writer = wave.open (out_file, "w")

        writer.setparams (self.reader.getparams ())
        writer.setnchannels (1)

        # The filter is just to take the mean of every batch ('n_elems' samples)
        batch = self.get_batch (n_elems)

        while len (batch) > 0:
            n_elems = len (batch)

            # Should be an integer
            mean = sum ( [ abs (self.hex2int (x)) for x in batch] ) / n_elems

            data_buffer = "".join ([ self.int2hex (mean) for _ in xrange (n_elems) ])
            writer.writeframes (data_buffer)

            batch = self.get_batch (n_elems)

    def filter_and_square_wave (self, out_file):
        """
        Applies a filter to the wave, squares it and stores it on the specified
        output file. This method is faster than filter_wave and then square_wave, as
        the file is processed in one take; but the results may be worse, as the threshold
        is chosen arbitrarily, without taken in account the max and min values

        Args:
            out_file -> Name of the file to store the filtered wave
        """
        writer = wave.open (out_file, "w")

        writer.setparams (self.reader.getparams ())
        writer.setnchannels (1)

        ff = self.int2hex ((2 ** 15) - 1)
        zero = self.int2hex (0)

        threshold = ((2 ** 15) - 1) * 1 / 3

        n_elems = 50
        # The filter is just to take the mean of every batch ('n_elems' samples)
        batch = self.get_batch (n_elems)

        while len (batch) > 0:
            n_elems = len (batch)

            # Should be an integer
            mean = sum ( [ abs (self.hex2int (x)) for x in batch] ) / n_elems

            data_buffer = "".join ([
                        ff if (mean >= threshold)
                        else zero
                        for i in xrange (n_elems)
            ])

            writer.writeframes (data_buffer)

            batch = self.get_batch (n_elems)



    def get_minmax (self):
        """
        Returns the minimum and the maximum values on the file.

        The position of the pointer is let as it was before entering the function

        Returns:
            A dictionary with the min and max values, on integer format
        """
        pos = self.get_pos ()
        frame = "".join (self.get_batch (1))

        min_max = {
            "min": self.hex2int (frame)
            , "max": self.hex2int (frame)
        }

        for _ in xrange (self.reader.getnframes () / self.buff_size):
            batch = self.get_batch (self.buff_size)

            for frame in batch:
                converted = self.hex2int (frame)

                if converted > min_max ["max"]:
                    min_max ["max"] = converted

                if converted < min_max ["min"]:
                    min_max ["min"] = converted

        # Restarts the pointer where it was
        self.set_pos (pos)

        return min_max



    def square_wave (self, out_file):
        """
        Gets the wave on the input file and manipulates it to leave it with only two
        values (the max and the min), converting it into a square wave
        Then, stores it on the specified output file

        Args:
            out_file -> Name of the file to store the filtered wave
        """
        reader = self.reader

        writer = wave.open (out_file, "w")

        writer.setparams (reader.getparams ())
        writer.setnchannels (1)

        n_frames = reader.getnframes ()

        # Calculates the threshold
        min_max = self.get_minmax ()
        threshold = min_max ["min"] + (
                (min_max ["max"] - min_max ["min"]) * 1 / 3
        )

        ff = self.int2hex (min_max ["max"])
        zero = self.int2hex (min_max ["min"])

        batch = self.get_batch (self.buff_size)
        while len (batch) > 0:

            data_buffer = ""
            for frame in batch:
                converted = self.hex2int (frame)

                if converted <= threshold:
                    data_buffer += zero
                else:
                    data_buffer += ff

            writer.writeframes (data_buffer)

            batch = self.get_batch (self.buff_size)

        return


    # ------------------ PROTOCOL-SPECIFIC METHODS ------------------


    ###
    # Bits encoded on 4-parts windows:
    #   1 => 3 time H + 1 time L (H H H L)
    #   0 => 1 time H + 3 time L (H L L L)
    ###


    def get_pulse_minmax (self, pulse = None):
        """
        Returns the minimum and the maximum lengths (duration of a pulse) of the waves.
        This method takes for granted that the file has already a square wave. That
        means that the duration to count will be the pulses of max value

        The position of the pointer is let as it was before entering the function

        Args:
            pulse (optional) -> An integer to specify the value that will be taken as a
                pulse (a high level)

        Returns:
            A dictionary with the min and max values (the number of repeated values for
            each pulse)
        """
        pos = self.get_pos ()

        min_max = {
            "min": None
            , "max": None
        }

        # Gets the value that will be taken as a pulse
        if not pulse:
            pulse = self.get_minmax () ["max"]

        counter = 0
        previous = self.hex2int ("".join (self.get_batch (1)))

        batch = self.get_batch (self.buff_size)
        while len (batch) > 0:

            for frame in batch:
                frame = self.hex2int (frame)
                # Pulse is on
                if frame == pulse:
                    if frame == previous:
                        counter += 1
                        previous = frame
                    else:
                        # The pulse has ended
                        if not min_max ["max"] or counter > min_max ["max"]:
                            min_max ["max"] = counter

                        if not min_max ["min"] or counter < min_max ["min"]:
                            min_max ["min"] = counter

                        counter = 0

                # Updates the frame
                previous = frame

            batch = self.get_batch (self.buff_size)

        # Restarts the pointer where it was
        self.set_pos (pos)

        return min_max


    def get_data (self):
        """
        Retrieves the data from the squared wave and returns it as an array with the bits
        of every packet. A new packet is detected if the length between one pulse and the
        next is larger than the duration of min_pulse + max_pulse (a whole window)

        This method takes for granted that the file has already a square wave. That
        means that the duration to count will be the pulses of max value


        Returns:
            An array of strings with all the encountered bits of every packet
        """
        packets = []
        data = ""

        # Gets the value that will be taken as a pulse
        pulse = self.get_minmax () ["max"]

        min_max = self.get_pulse_minmax (pulse)

        # Checks that the returned value may be handled (if the signal hasn't been
        # correctly processed, it may even be plain)
        if not min_max ["max"] or not min_max ["min"]:
            return []

        # Factor to differentiate between pulses.
        # E.g.:
        #   min_max ["max"] = 100 ; max_diff = 0.05
        #   if a pulse lasts between 95 and 105 frames, its taken as a 'max' pulse
        max_diff = 0.05
        threshold = {
            "max": min_max ["max"] * max_diff
            , "min": min_max ["min"] * max_diff
        }

        # Minimum distance (in frames) between packets
        packet_distance = min_max ["max"] + threshold ["max"] \
                         + min_max ["min"] + threshold ["min"]

        counter = 0
        pulse_duration = 0
        previous = self.hex2int ("".join (self.get_batch (1)))

        batch = self.get_batch ()
        while len (batch) > 0:

            for frame in batch:
                frame = self.hex2int (frame)
                # Pulse is on
                if frame == pulse:
                    # Checks if this is another packet
                    if counter >= packet_distance and data:
                        packets.append (data)
                        data = ""

                    counter = 0
                    pulse_duration += 1
                else:
                    # Falling edge
                    if previous == pulse:
                        # The pulse was long -> it's a 1; otherwise -> it's a 0
                        if abs (pulse_duration - min_max ["max"]) <= threshold ["max"]:
                            data += "1"
                        else:
                            data += "0"

                    pulse_duration = 0
                    counter += 1

                # Updates the frame
                previous = frame


            batch = self.get_batch ()

        # Appends the final packet
        if data:
            packets.append (data)

        return packets
