#Time Wanderer

-------------------------------------------
Videojuego de plataformas estilo "roguelike" creado para la
asignatura "Tecnología de Videojuegos" por:

	-Zamar-Elahi Fazal Roura	- zamar.fazal@edu.uah.es
	-Miguel García Martín		- miguel.garciamartin@edu.uah.es
	-Sergio Sánchez López		- s.sanchezl@edu.uah.es
	-Alberto Serrano Ibaibarriaga	- alberto.serranoi@edu.uah.es
	-Pablo Peña Romero		- p.pena@edu.uah.es
-------------------------------------------


#Extracción del comprimido

	Las carpetas se han archivado con tar y se han comprimido con
gzip para crear un .tar.gz, que puede ser extraído con alguno de los
siguientes comandos:
	$> gzip --decompress Time-Wanderer-dist.tar.gz
	$> tar xfv Time-Wanderer-dist.tar
		(la 'v', de 'verbose', es opcional)

o, de otro modo, directamente con:
	$> tar xvfz Time-Wanderer-dist.tar.gz
		(la 'v', de 'verbose', es opcional)

	Si no se pueden ejecutar esos comandos (como, por ejemplo,
en Windows), se debería poder extraer todo correctamente con el
programa 7-Zip (o cualquier otro que lo soporte).



#Ejecución

	La carpeta contiene todo lo necesario para la ejecución del
videojuego. No es necesario nada más que hacer doble click sobre el
archivo .jar, o ejecutar el siguiente comando (en la carpeta en la
que se encuentre el ejecutable):
	$> java -jar Time-Wanderer
Debería funcionar sin problemas en Windows, MacOS y GNU/Linux.




#Instrucciones

	El juego consta de dos líneas temporales entre las que se
debe cambiar para poder pasar al siguiente nivel. Esto significa que
la línea temporal moderna tiene una serie de obstáculos (puertas
bloqueadas que impiden pasar a otra sala) que deben ser eliminados
desde la otra línea temporal (interactuando con las palancas que
aparecen por el mapa hasta encontrar la corrrecta). Hasta que los
personajes de ambas líneas temporales no hayan acabado con los jefes
correspondientes, no se podrá pasar de nivel.
	Para obtener información sobre los controles, se puede
acceder al menú "controles" al inicio del juego.
